package networkpolicy

var DefaultSchemeAllowList = []string{
	"http",
	"https",
}
