// Package clistats implements a progress monitor functionality which exposes statistics
// in json format on a api endpoint bound to localhost
package clistats
