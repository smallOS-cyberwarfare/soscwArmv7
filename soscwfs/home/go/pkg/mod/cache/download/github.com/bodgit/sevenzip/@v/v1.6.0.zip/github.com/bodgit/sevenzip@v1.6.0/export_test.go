package sevenzip

var ErrMissingUnpackInfo = errMissingUnpackInfo
