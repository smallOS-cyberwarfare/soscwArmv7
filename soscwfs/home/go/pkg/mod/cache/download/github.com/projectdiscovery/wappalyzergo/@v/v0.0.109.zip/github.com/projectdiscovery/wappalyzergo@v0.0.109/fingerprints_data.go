package wappalyzer

import (
	_ "embed"
)

//go:embed fingerprints_data.json
var fingerprints string
