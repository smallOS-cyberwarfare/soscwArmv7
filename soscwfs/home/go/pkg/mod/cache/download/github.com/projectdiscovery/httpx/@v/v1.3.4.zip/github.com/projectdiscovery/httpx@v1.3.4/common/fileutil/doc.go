// Package fileutil contains all the funcionality related to deal with files
package fileutil
