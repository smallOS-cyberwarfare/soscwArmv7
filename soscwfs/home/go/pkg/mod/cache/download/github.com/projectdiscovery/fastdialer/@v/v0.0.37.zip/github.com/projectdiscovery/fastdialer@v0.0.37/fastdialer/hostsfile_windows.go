// +build windows

package fastdialer

const HostsFilePath = "${SystemRoot}/System32/drivers/etc/hosts"
