// Package experimental contains experimental features that are not part of the
// standard library regexp package. There is no API stability guarantee for this
// package even across minor version updates.
package experimental
