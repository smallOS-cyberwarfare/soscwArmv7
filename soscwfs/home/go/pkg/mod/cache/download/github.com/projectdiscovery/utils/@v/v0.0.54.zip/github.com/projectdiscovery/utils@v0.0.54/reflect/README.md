# reflectutil
The package contains various helpers for reflection