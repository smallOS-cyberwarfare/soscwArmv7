# Release Notes v0.5.11

This release addresses an issues reported by Matty Dainty (@bodgit) as pull
request [#52](https://github.com/ulikunitz/xz/pull/52).
