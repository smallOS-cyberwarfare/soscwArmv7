// +build windows

package fastdialer

// To be implemented
const ResolverFilePath = ""
