[![Build Status](https://img.shields.io/github/workflow/status/bodgit/plumbing/build)](https://github.com/bodgit/plumbing/actions?query=workflow%3Abuild)
[![Coverage Status](https://coveralls.io/repos/github/bodgit/plumbing/badge.svg?branch=master)](https://coveralls.io/github/bodgit/plumbing?branch=master)
[![Go Report Card](https://goreportcard.com/badge/github.com/bodgit/plumbing)](https://goreportcard.com/report/github.com/bodgit/plumbing)
[![GoDoc](https://godoc.org/github.com/bodgit/plumbing?status.svg)](https://godoc.org/github.com/bodgit/plumbing)
![Go version](https://img.shields.io/badge/Go-1.19-brightgreen.svg)
![Go version](https://img.shields.io/badge/Go-1.18-brightgreen.svg)

plumbing
========

Assorted I/O U-bends, T-pieces, etc.
