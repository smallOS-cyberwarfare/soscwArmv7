## Description

Extended version of https://github.com/roman-kachanovsky/go-binary-pack