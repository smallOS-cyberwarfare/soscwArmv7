# mapsutil
The package contains various helpers to interact with maps