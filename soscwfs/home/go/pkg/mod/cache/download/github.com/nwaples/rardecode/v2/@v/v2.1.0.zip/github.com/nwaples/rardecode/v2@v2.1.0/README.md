# rardecode
[![GoDoc](https://godoc.org/github.com/nwaples/rardecode?status.svg)](https://godoc.org/github.com/nwaples/rardecode)
[![Go Report Card](https://goreportcard.com/badge/github.com/nwaples/rardecode/v2)](https://goreportcard.com/report/github.com/nwaples/rardecode/v2)

A go package for reading RAR archives.
