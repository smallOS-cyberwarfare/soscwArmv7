package tests

type Test struct {
	unexported string //nolint
}
