package mlutils

type LabeledDocument struct {
	Label    string
	Document string
}
