package extensions

const (
	JSON = ".json"
	YAML = ".yaml"
	YML  = ".yml"
)
