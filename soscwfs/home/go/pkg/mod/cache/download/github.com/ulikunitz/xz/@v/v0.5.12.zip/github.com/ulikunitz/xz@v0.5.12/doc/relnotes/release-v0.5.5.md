# Release Notes v0.5.5

This release fixes the issue
[issue 19](https://github.com/ulikunitz/xz/issues/19).
Many thanks for Scott Crelay to report it and Dell Green to provide a sample
file.

The release does also include the
[pull request 17](https://github.com/ulikunitz/xz/pull/17) from Ondrej Fabry.
