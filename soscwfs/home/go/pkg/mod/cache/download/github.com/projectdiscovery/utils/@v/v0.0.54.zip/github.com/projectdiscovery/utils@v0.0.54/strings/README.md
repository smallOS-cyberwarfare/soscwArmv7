# stringsutil
The package contains various helpers to interact with strings