//go:build race

// Package raceutil reports if the Go race detector is enabled.
package raceutil

// Enabled reports if the race detector is enabled.
const Enabled = true
