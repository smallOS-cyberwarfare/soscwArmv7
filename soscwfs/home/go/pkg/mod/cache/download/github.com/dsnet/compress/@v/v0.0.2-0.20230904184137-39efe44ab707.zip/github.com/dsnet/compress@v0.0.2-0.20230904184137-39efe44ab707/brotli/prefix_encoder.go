// Copyright 2015, Joe Tsai. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE.md file.

package brotli

type prefixEncoder struct{}

func (pe *prefixEncoder) Init(codes []prefixCode) {}
