## Description

<!-- Describe your changes in detail. -->

<!--
If it resolves an open issue, link to the issue here, otherwise remove this
line.
-->

Closes #

## Additional context

<!-- If you have any other context, describe them here. -->

## Checklist

- [ ] I have read the [Contribution Guide].
- [ ] I agree to follow the [Code of Conduct].

[Contribution Guide]: https://github.com/sorairolake/lzip-go/blob/develop/CONTRIBUTING.adoc
[Code of Conduct]: https://github.com/sorairolake/lzip-go/blob/develop/CODE_OF_CONDUCT.md
