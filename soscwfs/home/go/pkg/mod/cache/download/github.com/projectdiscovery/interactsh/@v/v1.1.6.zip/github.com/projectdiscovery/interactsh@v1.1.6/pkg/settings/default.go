package settings

const (
	CorrelationIdLengthDefault      = 20
	CorrelationIdNonceLengthDefault = 13
	StorePayloadFileDefault         = "interactsh_payload.txt"
)
