// Package customheader contains all the funcionality to deal with Custom Global Headers
package customheader
