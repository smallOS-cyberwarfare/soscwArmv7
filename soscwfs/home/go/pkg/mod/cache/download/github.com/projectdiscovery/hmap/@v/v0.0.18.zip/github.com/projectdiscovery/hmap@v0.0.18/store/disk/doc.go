package disk

// Forked ad adapted from https://github.com/alash3al/redix/blob/master/kvstore/leveldb/leveldb.go
