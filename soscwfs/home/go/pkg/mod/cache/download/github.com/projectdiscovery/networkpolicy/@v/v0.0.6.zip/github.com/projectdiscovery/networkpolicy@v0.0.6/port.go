package networkpolicy

var DefaultPortAllowList = []int{
	80,
	443,
}
