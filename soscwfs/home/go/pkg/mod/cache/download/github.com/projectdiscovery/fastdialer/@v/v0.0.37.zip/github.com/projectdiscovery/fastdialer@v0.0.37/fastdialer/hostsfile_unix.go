// +build !windows

package fastdialer

// HostsFilePath in unix file os
const HostsFilePath = "/etc/hosts"
