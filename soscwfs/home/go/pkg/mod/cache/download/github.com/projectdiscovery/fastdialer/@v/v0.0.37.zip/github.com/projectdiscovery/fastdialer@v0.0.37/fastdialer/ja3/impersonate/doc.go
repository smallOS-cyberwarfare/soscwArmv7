// impersonate package contains strategy to impersonate a client and define an alias for the internal
// client tls spefications
package impersonate
