package networkpolicy

var DefaultIPv4Denylist = []string{
	"255.255.255.255", // Broadcast
}
var DefaultIPv6Denylist = []string{}
