seekinghttp
===========

An implementation of io.ReaderAt that works via GET and the Range header.

This was discussed in an article for [Gopher Academy](https://blog.gopheracademy.com/advent-2017/seekable-http/) in 2017.

