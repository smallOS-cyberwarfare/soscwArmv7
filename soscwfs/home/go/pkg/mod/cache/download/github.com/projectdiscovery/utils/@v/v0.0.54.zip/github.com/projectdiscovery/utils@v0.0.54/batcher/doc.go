// batcher is a package that provides a simple batching mechanism
// the buffer can be configured with a max capacity and a flush interval
// the buffer will invoke a callback function when the buffer is full or the flush interval is reached
package batcher
