# cryptoutil
The package contains various helpers about crypto