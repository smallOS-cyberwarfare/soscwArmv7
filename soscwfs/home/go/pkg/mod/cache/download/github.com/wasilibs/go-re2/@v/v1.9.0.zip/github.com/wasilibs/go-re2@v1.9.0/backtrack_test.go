package re2

const maxBacktrackVector = 256 * 1024
