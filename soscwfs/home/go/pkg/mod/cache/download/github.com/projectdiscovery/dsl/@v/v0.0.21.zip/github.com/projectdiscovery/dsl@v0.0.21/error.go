package dsl

import "errors"

var ErrInvalidDslFunction = errors.New("invalid DSL function signature")
