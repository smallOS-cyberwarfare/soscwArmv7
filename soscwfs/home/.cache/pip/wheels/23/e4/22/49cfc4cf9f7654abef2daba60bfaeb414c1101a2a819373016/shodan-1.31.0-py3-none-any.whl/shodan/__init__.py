from shodan.client import Shodan
from shodan.exception import APIError
